r"""Helper v4 (2026-10-26) for the 334 CLIENT (DreamSeeker): helper v2 (printf %n emulation incl. the text after %n)
plus one fix for joining servers. Needs host334v2.py and strace.py next to it. v1-v3 unchanged.

Problem (verified 2026-10-26): SocketLib::OpenClientSocket (byond.dll 0x100f21f0) starts a non-blocking connect()
and only THEN asks Windows (WSAAsyncSelect) to post FD_CONNECT to its window. On today's Windows a connect that has
already finished by then (loopback, LAN) gets no FD_CONNECT, so DreamSeeker waits at "Connecting to ..." forever.
v4: when OpenClientSocket leaves a socket waiting, a helper thread watches Windows' TCP table; as soon as that
connection is ESTABLISHED and no FD_CONNECT has reached SocketLib::Event_io (0x100f2e00), it posts the FD_CONNECT
message (socket window + message number from byond.dll's socklib, wParam = socket, lParam = 0x10) - the notice
older Windows delivered. If the connection fails, nothing is posted (Windows reports FD_CLOSE as usual).
  python -I host334v4.py C:\...\dreamseeker.exe [args]"""
import sys, os, struct, threading, time, ctypes, ctypes.wintypes as W
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import host334v2 as H

u32 = ctypes.WinDLL('user32'); ip = ctypes.WinDLL('iphlpapi')
u32.PostMessageW.argtypes = [W.HWND, W.UINT, W.WPARAM, W.LPARAM]
SOCKLIB_VA = 0x101d6618                     # ?socklib@@3USocketLib@@A: +0x14 socket window, +0x1c message number

def established(pid, raddr, rport):
    """Is there an ESTABLISHED IPv4 TCP connection owned by pid to raddr:rport? (GetExtendedTcpTable, owner-pid)"""
    size = W.DWORD(0)
    ip.GetExtendedTcpTable(None, ctypes.byref(size), False, 2, 5, 0)
    buf = ctypes.create_string_buffer(size.value + 4096); size = W.DWORD(len(buf))
    if ip.GetExtendedTcpTable(buf, ctypes.byref(size), False, 2, 5, 0) != 0: return False
    n = struct.unpack_from('<I', buf.raw, 0)[0]
    for i in range(n):
        state, la, lp, ra, rp, opid = struct.unpack_from('<IIIIII', buf.raw, 4 + 24 * i)
        port = struct.unpack('>H', struct.pack('<I', rp)[:2])[0]      # stored in network byte order
        if opid == pid and state == 5 and ra == raddr and port == rport: return True
    return False

BYOND334_DLL_MD5 = 'e8937bce2b93286eaf88fe29d03dcaaf'   # byond.dll of BYOND 334 (byond_update.exe, 2003)

def byond_dll_is_334(exe):
    import hashlib
    try: return hashlib.md5(open(os.path.join(os.path.dirname(exe), 'byond.dll'), 'rb').read()).hexdigest() == BYOND334_DLL_MD5
    except OSError: return False

class Host4(H.Host):
    def __init__(s, exe, args='', cwd=None, log=None, hooks=None):
        s.connect_seen = set()
        hk = dict(hooks or {})
        if byond_dll_is_334(exe):                         # the addresses below are those of byond.dll 334 only
            hk[0x100f21f0] = s._open_client; hk[0x100f2e00] = s._event_io
        elif log:
            log('v4: bin\\byond.dll is not the BYOND 334 one - the "connected" fix is OFF (helper v2 only)')
        H.Host.__init__(s, exe, args, cwd, log, hk)
    def _event_io(s, h, ctx):
        sock, lp = struct.unpack('<II', h.rd(ctx.Esp + 4, 8))
        if lp & 0xffff == 0x10: s.connect_seen.add(sock & 0xffff)
    def _open_client(s, h, ctx):
        sa = struct.unpack('<I', h.rd(ctx.Esp + 4, 4))[0]; b = h.rd(sa, 8)
        rport = struct.unpack('>H', b[2:4])[0]; raddr = struct.unpack('<I', b[4:8])[0]
        def after(h2, c2):
            sock = c2.Eax
            if sock == 0xffffffff: return                      # finished at once or failed: callback already ran
            sl = h2.base + SOCKLIB_VA - 0x10000000
            hwnd, msg = struct.unpack('<I', h2.rd(sl + 0x14, 4))[0], struct.unpack('<I', h2.rd(sl + 0x1c, 4))[0]
            def watch():
                for _ in range(300):                          # up to ~30 s
                    time.sleep(0.1)
                    if (sock & 0xffff) in s.connect_seen: return
                    if established(h2.pid, raddr, rport):
                        time.sleep(0.2)
                        if (sock & 0xffff) in s.connect_seen: return
                        u32.PostMessageW(hwnd, msg, sock, 0x10)
                        s.log('v4: connection to %d.%d.%d.%d:%d is up but Windows sent no FD_CONNECT - posted it '
                              '(socket %#x, window %#x, message %#x)' % (b[4], b[5], b[6], b[7], rport, sock, hwnd, msg))
                        return
            threading.Thread(target=watch, daemon=True).start()
        return after

if __name__ == '__main__':
    h = Host4(sys.argv[1], ' '.join('"%s"' % a for a in sys.argv[2:]), log=lambda m: print(m, flush=True))
    h.start(); h.wait(); print('exit', h.exit_code, 'fixes', h.fixes, 'tail fixes', h.tailfixes, flush=True)
