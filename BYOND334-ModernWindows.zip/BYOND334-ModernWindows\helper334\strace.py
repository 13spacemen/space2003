"""Minimal Windows debugger (ctypes) that runs dm.exe and logs every string-pool event of byondcore.dll (session 6).
Breakpoints:  FUN_100b6aa0 (intern: arg1 = ptr to struct whose first field is char*)  and  FUN_100b9020 (release: arg1 = slot).
Usage: python -I strace.py <project_dir> <file.dme> <out.tsv>
Output rows: kind \t caller(VA relative to image base 0x10000000) \t caller2 \t text-or-slot
The slot numbers are reproduced afterwards by replay (first free slot, refcount) in strreplay.py.
"""
import ctypes, ctypes.wintypes as W, sys, struct, os
k32 = ctypes.WinDLL('kernel32', use_last_error=True)
DEBUG_ONLY_THIS_PROCESS = 2
EXCEPTION_DEBUG_EVENT, CREATE_PROCESS_DEBUG_EVENT, EXIT_PROCESS_DEBUG_EVENT, LOAD_DLL_DEBUG_EVENT = 1, 3, 5, 6
DBG_CONTINUE, DBG_EXCEPTION_NOT_HANDLED = 0x00010002, 0x80010001
EXC_BREAKPOINT, EXC_SINGLE_STEP = 0x80000003, 0x80000004
STATUS_WX86_BREAKPOINT, STATUS_WX86_SINGLE_STEP = 0x4000001F, 0x4000001E
class STARTUPINFO(ctypes.Structure):
    _fields_ = [('cb', W.DWORD), ('lpReserved', W.LPWSTR), ('lpDesktop', W.LPWSTR), ('lpTitle', W.LPWSTR), ('dwX', W.DWORD), ('dwY', W.DWORD),
                ('dwXSize', W.DWORD), ('dwYSize', W.DWORD), ('dwXCountChars', W.DWORD), ('dwYCountChars', W.DWORD), ('dwFillAttribute', W.DWORD),
                ('dwFlags', W.DWORD), ('wShowWindow', W.WORD), ('cbReserved2', W.WORD), ('lpReserved2', ctypes.c_void_p),
                ('hStdInput', W.HANDLE), ('hStdOutput', W.HANDLE), ('hStdError', W.HANDLE)]
class PROCESS_INFORMATION(ctypes.Structure):
    _fields_ = [('hProcess', W.HANDLE), ('hThread', W.HANDLE), ('dwProcessId', W.DWORD), ('dwThreadId', W.DWORD)]
class DEBUG_EVENT(ctypes.Structure):
    _fields_ = [('dwDebugEventCode', W.DWORD), ('dwProcessId', W.DWORD), ('dwThreadId', W.DWORD), ('_pad', W.DWORD), ('u', ctypes.c_byte * 176)]
class WOW64_CONTEXT(ctypes.Structure):
    _fields_ = [('ContextFlags', W.DWORD), ('Dr', W.DWORD * 6), ('FloatSave', ctypes.c_byte * 112), ('SegGs', W.DWORD), ('SegFs', W.DWORD),
                ('SegEs', W.DWORD), ('SegDs', W.DWORD), ('Edi', W.DWORD), ('Esi', W.DWORD), ('Ebx', W.DWORD), ('Edx', W.DWORD), ('Ecx', W.DWORD),
                ('Eax', W.DWORD), ('Ebp', W.DWORD), ('Eip', W.DWORD), ('SegCs', W.DWORD), ('EFlags', W.DWORD), ('Esp', W.DWORD), ('SegSs', W.DWORD),
                ('Ext', ctypes.c_byte * 512)]
WOW64_CONTEXT_FULL = 0x00010000 | 0x1 | 0x2 | 0x4
k32.OpenThread.restype = W.HANDLE
import os as _os
DEEP = int(_os.environ.get('STRACE_DEEP', '0'))
CH = ['']
def main(projdir, dme, outpath, dm=r'C:\nb3\byond512\x\byond\bin\dm.exe'):
    si = STARTUPINFO(); si.cb = ctypes.sizeof(si); pi = PROCESS_INFORMATION()
    cmd = ctypes.create_unicode_buffer('"%s" -max_errors 100000 %s' % (dm, dme))
    if not k32.CreateProcessW(None, cmd, None, None, False, DEBUG_ONLY_THIS_PROCESS, None, projdir, ctypes.byref(si), ctypes.byref(pi)):
        raise OSError(ctypes.get_last_error())
    hp = pi.hProcess
    def rd(addr, n):
        b = ctypes.create_string_buffer(n); got = ctypes.c_size_t()
        k32.ReadProcessMemory(hp, ctypes.c_void_p(addr), b, n, ctypes.byref(got)); return b.raw[:got.value]
    def wr(addr, data):
        got = ctypes.c_size_t(); old = W.DWORD()
        k32.VirtualProtectEx(hp, ctypes.c_void_p(addr), len(data), 0x40, ctypes.byref(old))
        k32.WriteProcessMemory(hp, ctypes.c_void_p(addr), data, len(data), ctypes.byref(got))
        k32.VirtualProtectEx(hp, ctypes.c_void_p(addr), len(data), old.value, ctypes.byref(old))
        k32.FlushInstructionCache(hp, ctypes.c_void_p(addr), len(data))
    def cstr(addr):
        out = b''
        while addr and len(out) < 100000:
            c = rd(addr, min(256, 0x1000 - (addr & 0xfff)))   # never cross a page boundary in one read
            if not c: break
            i = c.find(b'\0')
            if i >= 0: return out + c[:i]
            out += c; addr += len(c)
        return out
    base = None; bps = {}; orig = {}; pending = {}  # thread -> bp addr to re-arm
    out = open(outpath, 'w', encoding='latin-1', newline='\n')
    ev = DEBUG_EVENT(); n = 0; first_bp = True
    threads = {}
    while True:
        if not k32.WaitForDebugEvent(ctypes.byref(ev), 0xFFFFFFFF): raise OSError(ctypes.get_last_error())
        code = ev.dwDebugEventCode; cont = DBG_CONTINUE
        if code == LOAD_DLL_DEBUG_EVENT:
            hfile, lpbase = struct.unpack_from('<QQ', bytes(ev.u), 0)
            # identify the dll by reading its export name is complex; use the module file name via GetFinalPathNameByHandle
            buf = ctypes.create_unicode_buffer(600)
            k32.GetFinalPathNameByHandleW(W.HANDLE(hfile), buf, 600, 0)
            if buf.value.lower().endswith('byondcore.dll') and base is None:
                base = lpbase
                for name, va in (('I', 0x100b6aa0), ('R', 0x100b9020)):
                    a = base + va - 0x10000000; orig[a] = rd(a, 1); bps[a] = name; wr(a, b'\xcc')
            if hfile: k32.CloseHandle(W.HANDLE(hfile))
        elif code == EXCEPTION_DEBUG_EVENT:
            exc_code, = struct.unpack_from('<I', bytes(ev.u), 0)
            exc_addr, = struct.unpack_from('<Q', bytes(ev.u), 16)
            th = k32.OpenThread(0x1FFFFF, False, ev.dwThreadId)
            ctx = WOW64_CONTEXT(); ctx.ContextFlags = WOW64_CONTEXT_FULL
            if exc_code in (EXC_BREAKPOINT, STATUS_WX86_BREAKPOINT):
                k32.Wow64GetThreadContext(th, ctypes.byref(ctx))
                a = ctx.Eip - 1
                if a in bps:
                    esp = ctx.Esp
                    ret, arg1, arg2 = struct.unpack('<III', rd(esp, 12))
                    r2 = rd(ctx.Ebp + 4, 4)   # caller's own return address (EBP chain, may be unreliable)
                    c2 = (struct.unpack('<I', r2)[0] - base + 0x10000000) & 0xffffffff if len(r2) == 4 else 0
                    if DEEP:   # further return addresses along the EBP chain, appended to c2 as x/y/z...
                        chain = []; fp = ctx.Ebp
                        for _ in range(DEEP):
                            fr = rd(fp, 8)
                            if len(fr) < 8: break
                            fp, ra = struct.unpack('<II', fr)
                            chain.append('%x' % ((ra - base + 0x10000000) & 0xffffffff))
                            if not fp: break
                        c2 = int(chain[0], 16) if chain else c2
                        CH[0] = '/'.join(chain[1:])
                    # second return address: walk EBP chain one step is unreliable; take raw stack scan of caller frame
                    if bps[a] == 'I':
                        p, = struct.unpack('<I', rd(arg1, 4)); txt = cstr(p)
                        out.write('I\t%x/%x%s\t%s\n' % (ret - base + 0x10000000, c2, ('/' + CH[0]) if DEEP and CH[0] else '', txt.decode('latin-1').replace('\\', '\\\\').replace('\n', '\\n').replace('\t', '\\t').replace('\r', '\\r')))
                    else:
                        out.write('R\t%x/%x%s\t%d\n' % (ret - base + 0x10000000, c2, ('/' + CH[0]) if DEEP and CH[0] else '', arg1))
                    n += 1
                    wr(a, orig[a]); ctx.Eip = a; ctx.EFlags |= 0x100
                    k32.Wow64SetThreadContext(th, ctypes.byref(ctx)); pending[ev.dwThreadId] = a
                else:
                    cont = DBG_CONTINUE  # initial loader breakpoint(s)
            elif exc_code in (EXC_SINGLE_STEP, STATUS_WX86_SINGLE_STEP) and ev.dwThreadId in pending:
                wr(pending.pop(ev.dwThreadId), b'\xcc')
            else:
                cont = DBG_EXCEPTION_NOT_HANDLED
            k32.CloseHandle(W.HANDLE(th))
        elif code == CREATE_PROCESS_DEBUG_EVENT:
            hfile, = struct.unpack_from('<Q', bytes(ev.u), 0)
            if hfile: k32.CloseHandle(W.HANDLE(hfile))
        elif code == EXIT_PROCESS_DEBUG_EVENT:
            k32.ContinueDebugEvent(ev.dwProcessId, ev.dwThreadId, cont); break
        k32.ContinueDebugEvent(ev.dwProcessId, ev.dwThreadId, cont)
    out.close()
    print('events', n, 'base', hex(base or 0))
if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3])
