@echo off
rem Open a project in the 2003 Dream Maker 334 (drag the .dme onto this file). Then menu Build, Compile.
call "%~dp0helper334\run334.bat" compile %*
