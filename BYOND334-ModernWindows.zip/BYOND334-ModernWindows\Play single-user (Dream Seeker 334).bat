@echo off
rem Play a world single-user in the 2003 Dream Seeker (drag the .dmb onto this file, or double-click and drag it into the window).
call "%~dp0helper334\run334.bat" play %*
