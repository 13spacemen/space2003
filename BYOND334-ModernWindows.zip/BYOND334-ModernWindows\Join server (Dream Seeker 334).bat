@echo off
rem Join a BYOND 334 server with the 2003 Dream Seeker, as Guest. Optional argument: address (default: asks, Enter = 127.0.0.1:5000).
call "%~dp0helper334\run334.bat" join %*
