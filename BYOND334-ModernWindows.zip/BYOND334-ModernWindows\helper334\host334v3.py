"""Run a BYOND 334 program under a tiny debugger that emulates printf '%n' (disabled in modern msvcrt.dll, which made
byond.dll 334 crash at startup: sprintf(buf, "%s%s%s%s%n%s", ...) left its count unset - VERIFIED 2026-10-21).
No file is changed: at each msvcrt!sprintf call whose format holds %n we let it run, then write the count ourselves.
v2 (2026-10-26): today's msvcrt also drops the text AFTER %n; for "%s%s%s%s%n%s" (byond.dll path builder
FUN_100ccf40, e.g. "<userpath>" + "key.txt") v2 also writes that last %s at buf+count and fixes sprintf's return
value, so the string is what the 2003 C library produced. (v1 = host334.py, unchanged.)
v3 (2026-10-26) = v2 + one in-memory change in byond.dll for hosting worlds whose background loop never runs out of
zero-delay work (cellautomata): TimeLib::Backlogged skips the timer that is running right now (0x100de342
JZ, 74 05). Dream Daemon then has no timer the check may look at (in 2003 its BYOND-network timers were there), so
the tick never ends. v3 writes 90 90 there, so the running tick timer counts too; the 0.5 s rule is unchanged.
Only applied when the bytes are exactly 74 05 (byond.dll 334). (v2 = host334v2.py, unchanged.)
Env HOST334_DEBUG=1 logs the first such fixes (buffer before/after, return value).
  as a library:  h = Host(exe, args, cwd); h.start(); ... h.pid ... h.wait()
  command line:  python -I host334.py C:\\ns4\\b334x\\bin\\dreamdaemon.exe [args...]"""
import ctypes, ctypes.wintypes as W, sys, struct, os, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))   # kit\strace.py = copy of C:\nb3\work\strace.py
import strace as S
k32 = S.k32

def export_rva(dll_path, name):
    d = open(dll_path, 'rb').read()
    pe = struct.unpack_from('<I', d, 0x3c)[0]; nsec = struct.unpack_from('<H', d, pe + 6)[0]
    optsz = struct.unpack_from('<H', d, pe + 20)[0]; opt = pe + 24
    exp_rva = struct.unpack_from('<I', d, opt + 96)[0]
    secs = [(struct.unpack_from('<I', d, opt + optsz + 40 * i + 12)[0], struct.unpack_from('<I', d, opt + optsz + 40 * i + 8)[0],
             struct.unpack_from('<I', d, opt + optsz + 40 * i + 20)[0]) for i in range(nsec)]
    off = lambda r: next(r - va + raw for va, vs, raw in secs if va <= r < va + vs)
    e = off(exp_rva); nfun, nnames, afun, aname, aord = struct.unpack_from('<IIIII', d, e + 20)
    for i in range(nnames):
        o = off(struct.unpack_from('<I', d, off(aname) + 4 * i)[0])
        if d[o:d.index(b'\0', o)] == name:
            return struct.unpack_from('<I', d, off(afun) + 4 * struct.unpack_from('<H', d, off(aord) + 2 * i)[0])[0]

DEBUG = os.environ.get('HOST334_DEBUG') == '1'
def byond_dll_is_334(exe):
    """True if bin\\byond.dll is the BYOND 334 one (md5 e8937bce...); v3's address is only valid there."""
    import hashlib
    try: return hashlib.md5(open(os.path.join(os.path.dirname(exe), 'byond.dll'), 'rb').read()).hexdigest() == 'e8937bce2b93286eaf88fe29d03dcaaf'
    except OSError: return False

SPRINTF_RVA = export_rva(os.path.join(os.environ.get('SystemRoot', r'C:\Windows'), 'SysWOW64', 'msvcrt.dll'), b'sprintf')

class Host:
    def __init__(s, exe, args='', cwd=None, log=None, hooks=None):
        """hooks: {byond.dll VA (image base 0x10000000): fn(h, ctx) -> None or fn_ret(h, ctx)} ; inside a hook,
        h.rd(addr, n), h.cstr(addr), h.base (byond.dll load base), h.va(addr) (-> 0x10000000-based VA)"""
        s.exe, s.args, s.cwd = exe, args, cwd or os.path.dirname(exe); s.log = log or (lambda m: None)
        s.hooks = hooks or {}; s.base = None
        s.pid = None; s.exit_code = None; s.fixes = 0; s.tailfixes = 0; s.v3_done = False; s.is334 = byond_dll_is_334(exe); s.started = threading.Event(); s.done = threading.Event()
    def start(s):
        threading.Thread(target=s._run, daemon=True).start(); s.started.wait(10)
    def wait(s, t=None): return s.done.wait(t)
    def kill(s):
        if s.pid:
            h = k32.OpenProcess(1, False, s.pid); k32.TerminateProcess(h, 1); k32.CloseHandle(h)
    def _run(s):
        si = S.STARTUPINFO(); si.cb = ctypes.sizeof(si); pi = S.PROCESS_INFORMATION()
        cmd = ctypes.create_unicode_buffer('"%s" %s' % (s.exe, s.args))
        if not k32.CreateProcessW(None, cmd, None, None, False, S.DEBUG_ONLY_THIS_PROCESS, None, s.cwd, ctypes.byref(si), ctypes.byref(pi)):
            raise OSError(ctypes.get_last_error())
        s.pid = pi.dwProcessId; s.started.set(); hp = pi.hProcess
        def rd(a, n):
            b = ctypes.create_string_buffer(n); got = ctypes.c_size_t()
            k32.ReadProcessMemory(hp, ctypes.c_void_p(a), b, n, ctypes.byref(got)); return b.raw[:got.value]
        def wr(a, data):
            got = ctypes.c_size_t(); old = W.DWORD()
            k32.VirtualProtectEx(hp, ctypes.c_void_p(a), len(data), 0x40, ctypes.byref(old))
            k32.WriteProcessMemory(hp, ctypes.c_void_p(a), data, len(data), ctypes.byref(got))
            k32.VirtualProtectEx(hp, ctypes.c_void_p(a), len(data), old.value, ctypes.byref(old))
            k32.FlushInstructionCache(hp, ctypes.c_void_p(a), len(data))
        def cstr(a, lim=4096):
            out = b''
            while a and len(out) < lim:
                c = rd(a, min(256, 0x1000 - (a & 0xfff)))
                if not c: break
                i = c.find(b'\0')
                if i >= 0: return out + c[:i]
                out += c; a += len(c)
            return out
        bps = {}; pending = {}; rets = {}   # bps: addr -> original byte; rets: (thread, ret addr) -> (kind, data)
        def arm(a): bps.setdefault(a, rd(a, 1)); wr(a, b'\xcc')
        s.rd = rd; s.cstr = cstr; s.va = lambda a: a - s.base + 0x10000000
        hook_at = {}
        sp_entry = None; ev = S.DEBUG_EVENT()
        while True:
            k32.WaitForDebugEvent(ctypes.byref(ev), 0xFFFFFFFF)
            code = ev.dwDebugEventCode; cont = S.DBG_CONTINUE; u = bytes(ev.u)
            if code == S.LOAD_DLL_DEBUG_EVENT:
                hfile, base = struct.unpack_from('<QQ', u, 0)
                buf = ctypes.create_unicode_buffer(600); k32.GetFinalPathNameByHandleW(W.HANDLE(hfile), buf, 600, 0)
                if buf.value.lower().endswith('syswow64\\msvcrt.dll') and sp_entry is None:
                    sp_entry = base + SPRINTF_RVA; arm(sp_entry)
                if buf.value.lower().endswith('\\byond.dll') and s.base is None:
                    s.base = base
                    # arm later: the loader relocates byond.dll AFTER this event and would overwrite the 0xCC
                    for va, fn in s.hooks.items(): hook_at[base + va - 0x10000000] = fn
                if hfile: k32.CloseHandle(W.HANDLE(hfile))
            elif code == S.CREATE_PROCESS_DEBUG_EVENT:
                hfile, = struct.unpack_from('<Q', u, 0)
                if hfile: k32.CloseHandle(W.HANDLE(hfile))
            elif code == S.EXCEPTION_DEBUG_EVENT:
                exc, = struct.unpack_from('<I', u, 0); tid = ev.dwThreadId
                if exc in (S.EXC_BREAKPOINT, S.STATUS_WX86_BREAKPOINT):
                    if s.base is not None and not s.v3_done:   # after the loader relocated byond.dll
                        pa = s.base + 0xde342; cur = rd(pa, 2)
                        if not s.is334: s.v3_done = True; s.log('v3: bin\\byond.dll is not the BYOND 334 one - not changed')
                        elif cur == b'\x74\x05': wr(pa, b'\x90\x90'); s.v3_done = True; s.log('v3: Backlogged now counts the running timer')
                        elif cur == b'\x90\x90': s.v3_done = True
                        else: s.v3_done = True; s.log('v3: unexpected bytes %r at Backlogged - not changed' % cur)
                    for ha in hook_at:                   # (re)arm: the loader's relocation may overwrite an early 0xCC
                        if ha in pending.values(): continue
                        cur = rd(ha, 1)
                        if cur != b'\xcc': bps[ha] = cur; wr(ha, b'\xcc')
                    th = k32.OpenThread(0x1FFFFF, False, tid)
                    ctx = S.WOW64_CONTEXT(); ctx.ContextFlags = S.WOW64_CONTEXT_FULL; k32.Wow64GetThreadContext(th, ctypes.byref(ctx))
                    a = ctx.Eip - 1
                    if a in bps:
                        if a == sp_entry:
                            st = rd(ctx.Esp, 4 * 12); ret, buf_, fmt = struct.unpack_from('<III', st, 0)
                            f = cstr(fmt, 256)
                            if b'%n' in f:
                                args = struct.unpack_from('<9I', st, 12)
                                if f == b'%s%s%s%s%n%s':
                                    rets[(tid, ret)] = ('sum4', args[4], sum(len(cstr(x)) for x in args[:4]), buf_, args[5])
                                elif f.endswith(b'%n'):
                                    rets[(tid, ret)] = ('ret', args[f.count(b'%') - 1], 0, 0, 0)
                                else:
                                    s.log('unhandled %%n format %r' % f)
                                arm(ret)
                        if a in hook_at:
                            try: r = hook_at[a](s, ctx)
                            except Exception as e:
                                import traceback; traceback.print_exc(); r = None
                            if r is not None:
                                ret = struct.unpack('<I', rd(ctx.Esp, 4))[0]
                                rets[(tid, ret)] = ('cb', r, 0, 0, 0); arm(ret)
                        if (tid, a) in rets:
                            kind, ptr, val, obuf, tailp = rets.pop((tid, a))
                            if kind == 'cb': ptr(s, ctx)
                            else: wr(ptr, struct.pack('<I', ctx.Eax if kind == 'ret' else val)); s.fixes += 1
                            if kind == 'sum4':               # v2: restore the text after %n
                                tail = cstr(tailp)
                                if DEBUG and s.fixes <= 6:
                                    s.log('v2 fix: before %r eax=%d' % (cstr(obuf, 600), ctx.Eax & 0xffffffff))
                                wr(obuf + val, tail + b'\0'); ctx.Eax = val + len(tail)
                                if DEBUG and s.fixes <= 6: s.log('v2 fix: after  %r eax=%d' % (cstr(obuf, 600), ctx.Eax))
                                s.tailfixes += 1
                            if not any(k[1] == a for k in rets):
                                wr(a, bps.pop(a)); ctx.Eip = a; k32.Wow64SetThreadContext(th, ctypes.byref(ctx))
                                k32.CloseHandle(W.HANDLE(th)); k32.ContinueDebugEvent(ev.dwProcessId, tid, cont); continue
                        # step over the breakpoint and re-arm it
                        wr(a, bps[a]); ctx.Eip = a; ctx.EFlags |= 0x100; k32.Wow64SetThreadContext(th, ctypes.byref(ctx))
                        pending[tid] = a
                    k32.CloseHandle(W.HANDLE(th))
                elif exc in (S.EXC_SINGLE_STEP, S.STATUS_WX86_SINGLE_STEP) and tid in pending:
                    a = pending.pop(tid)
                    if a in bps: wr(a, b'\xcc')
                else:
                    cont = S.DBG_EXCEPTION_NOT_HANDLED
            elif code == S.EXIT_PROCESS_DEBUG_EVENT:
                s.exit_code = struct.unpack_from('<I', u, 0)[0]
                k32.ContinueDebugEvent(ev.dwProcessId, ev.dwThreadId, cont); break
            k32.ContinueDebugEvent(ev.dwProcessId, ev.dwThreadId, cont)
        s.done.set()

if __name__ == '__main__':
    h = Host(sys.argv[1], ' '.join('"%s"' % a for a in sys.argv[2:]), log=lambda m: print(m, flush=True))
    h.start(); h.wait(); print('exit', h.exit_code, 'fixes', h.fixes, 'tail fixes', h.tailfixes)
