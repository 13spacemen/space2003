r"""Join a BYOND 334 server with the 2003 Dream Seeker: runs dreamseeker.exe under helper v4 (host334v4.py) and,
once you are past the first screens (Diagnostics -> Cancel, Create/Retrieve Key -> Cancel, Login "Guest" -> OK),
opens File > Open Location, fills in the address and presses OK for you. Needs host334v4.py, host334v2.py and
strace.py next to it.
  python join334.py C:\...\dreamseeker.exe [ADDRESS=127.0.0.1:5000]"""
import sys, os, time, threading, ctypes, ctypes.wintypes as W
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import host334v4

EXE = sys.argv[1]; ADDR = sys.argv[2] if len(sys.argv) > 2 else '127.0.0.1:5000'
u = ctypes.WinDLL('user32'); ENUM = ctypes.WINFUNCTYPE(W.BOOL, W.HWND, W.LPARAM)
u.SendMessageW.argtypes = [W.HWND, W.UINT, W.WPARAM, ctypes.c_wchar_p]
u.PostMessageW.argtypes = [W.HWND, W.UINT, W.WPARAM, W.LPARAM]
u.GetMenu.argtypes = [W.HWND]; u.GetMenu.restype = W.HMENU
OPEN_LOCATION = 32773                                   # Dream Seeker 334 menu File > Open Location...

def text(h):
    b = ctypes.create_unicode_buffer(256); u.GetWindowTextW(h, b, 256); return b.value
def cls(h):
    b = ctypes.create_unicode_buffer(64); u.GetClassNameW(h, b, 64); return b.value
def tops(pid):
    res = []
    def cb(h, _):
        p = W.DWORD(); u.GetWindowThreadProcessId(h, ctypes.byref(p))
        if p.value == pid and u.IsWindowVisible(h): res.append(h)
        return True
    u.EnumWindows(ENUM(cb), 0); return res
def kids(h):
    res = []; u.EnumChildWindows(h, ENUM(lambda c, _: res.append(c) or True), 0); return res

def joiner(h):
    asked = False
    for _ in range(1200):                               # up to 10 minutes for you to get past the first screens
        time.sleep(0.5)
        if h.done.is_set() or not h.pid: return
        ws = tops(h.pid)
        mains = [w for w in ws if text(w).endswith('Dream Seeker') and u.GetMenu(w)]
        dialogs = [w for w in ws if w not in mains]
        loc = [w for w in dialogs if text(w) == 'Open Location']
        if loc:
            ed = [c for c in kids(loc[0]) if cls(c) == 'Edit']
            ok = [c for c in kids(loc[0]) if cls(c) == 'Button' and text(c) == 'OK']
            if ed and ok:
                u.SendMessageW(ed[0], 0x0C, 0, ADDR); u.PostMessageW(ok[0], 0xF5, 0, 0)
                print('Joining %s ...' % ADDR, flush=True); return
        elif mains and not dialogs and not asked:
            time.sleep(1); u.PostMessageW(mains[0], 0x111, OPEN_LOCATION, 0); asked = True

h = host334v4.Host4(EXE, '', log=lambda m: print(m, flush=True))
h.start()
threading.Thread(target=joiner, args=(h,), daemon=True).start()
h.wait()
