BYOND 334 (2003) on modern Windows - start files for hosting, joining and playing
==================================================================================

BYOND 334 is from 2003. On today's Windows its programs crash at startup, Dream Daemon freezes on busy worlds,
and Dream Seeker never finishes "Connecting to ...". These start files run the original 2003 programs with a small
helper that fixes those problems in memory while they run. No BYOND file and no game file is changed.

WHAT YOU NEED
  - BYOND version 334 (the 2003 files: a folder with bin\dreamseeker.exe, bin\dreamdaemon.exe, bin\byond.dll ...).
  - Python 3, 64-bit (free: https://www.python.org/downloads/windows/ - when installing, tick
    "Add python.exe to PATH"). Nothing else to install.

SETUP
  Copy this whole folder (BYOND334-ModernWindows, with the helper334 folder inside) into your BYOND 334 folder,
  i.e. next to its "bin" folder:
      BYOND 334\
          bin\
          BYOND334-ModernWindows\      <- this folder
  (Putting it inside bin\ also works.)

HOST A GAME (the 2003 way: Dream Daemon)
  Drag the world's .dmb onto "Host world (Dream Daemon 334).bat" (or double-click it and drag the .dmb into the
  window). It hosts on port 5000. Close the black window to stop the server.

JOIN A GAME (Dream Seeker)
  Double-click "Join server (Dream Seeker 334).bat". Press Enter for a server on the same PC, or type the host's
  address, e.g. 192.168.1.20:5000 or someone.example.com:5000. Then click through the first screens:
    - "Dream Seeker Diagnostics" (only if Dream Seeker was not closed normally last time): Cancel = run normally
    - "Create/Retrieve Key": Cancel
    - Login: "Guest" is already selected: OK
  The helper then opens File > Open Location with the address and connects. You play as Guest (BYOND's built-in
  offline key - the 2003 BYOND login servers are gone). Quit with File > Exit.

PLAY ALONE (single-user)
  Drag the .dmb onto "Play single-user (Dream Seeker 334).bat". Same first screens as above.

COMPILE (Dream Maker)
  Drag a .dme onto "Compile (Dream Maker 334).bat", then menu Build > Compile.

WHAT THE HELPER FIXES (all in memory, only while the programs run)
  1. All 334 programs use printf "%n", which today's Windows C library has switched off: they crashed at startup and
     lost the end of file names (e.g. key.txt). The helper supplies the missing value and text.
  2. Dream Daemon (host): busy worlds with endless background loops (e.g. SS13's air simulation) froze it. In 2003
     Dream Daemon's link to BYOND's servers kept timers running that let such loops pause; those servers are gone.
     The helper lets the server's own tick timer count instead (BYOND's 2003 half-second rule is unchanged).
  3. Dream Seeker (join): today's Windows does not send the "connect finished" notice when a connection completes
     at once (same PC / LAN), so it waited at "Connecting to ..." forever. The helper delivers that notice.
  Fixes 2 and 3 switch themselves off if bin\byond.dll is not the BYOND 334 one.

GOOD TO KNOW
  - Busy 2003 worlds run slowly on the 2003 engine (SS13 cellautomata: about 2 game ticks per second). That is how
    the original engine behaves; the server carries the load, the client stays light.
  - Joining over the internet: the host must allow port 5000 through Windows Firewall / the router. Tested so far:
    host and player on the same PC.
  - BYOND 334 keeps its own settings and its Guest key in its "users" folder (if a modern BYOND is installed, Windows
    redirects that to %LOCALAPPDATA%\VirtualStore\Program Files (x86)\BYOND\users\<you>\).
  - Windows may show a security prompt the first time (Python opening a network port / debugging the program):
    the helper starts the BYOND program as a debugger to apply the fixes; that is expected.

FILES
  Host world (Dream Daemon 334).bat, Join server (Dream Seeker 334).bat, Play single-user (Dream Seeker 334).bat,
  Compile (Dream Maker 334).bat   - the start files (each calls helper334\run334.bat)
  helper334\run334.bat   finds bin\ and Python, then starts the right helper
  helper334\host334v2.py fix 1 (Dream Maker, single-user Dream Seeker)
  helper334\host334v3.py fixes 1 + 2 (Dream Daemon)
  helper334\host334v4.py fixes 1 + 3 (Dream Seeker joining); join334.py runs it and does Open Location
  helper334\strace.py    small debugger library used by the helpers

Made 2026-10-26 while reviving the late-2003 SS13 "cellautomata" world.
