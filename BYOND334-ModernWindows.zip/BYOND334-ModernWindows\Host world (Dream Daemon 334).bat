@echo off
rem Host a world with the 2003 BYOND 334 Dream Daemon (drag the .dmb onto this file, or double-click and drag it into the window).
rem Optional 2nd argument: port (default 5000). Needs this package inside your BYOND 334 folder and 64-bit Python 3.
call "%~dp0helper334\run334.bat" host %*
