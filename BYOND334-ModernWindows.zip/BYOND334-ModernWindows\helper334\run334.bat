@echo off
rem Shared launcher for the BYOND 334 start files (do not run directly).
rem   run334.bat host    [world.dmb] [port]
rem   run334.bat join    [address]
rem   run334.bat play    [world.dmb]
rem   run334.bat compile [project.dme]
setlocal
set "HELPER=%~dp0"
set "MODE=%~1"

rem --- find BYOND 334's bin folder: this package folder sits in the BYOND folder (next to bin) or inside bin ---
rem     (this file is <package>\helper334\run334.bat)
set "BIN=%~dp0..\..\bin"
if exist "%BIN%\dreamseeker.exe" goto havebin
set "BIN=%~dp0..\.."
if exist "%BIN%\dreamseeker.exe" goto havebin
echo Could not find BYOND 334's programs.
echo Put this whole folder into your BYOND 334 folder - the one that contains "bin" - and try again.
goto fail
:havebin
for %%I in ("%BIN%") do set "BIN=%%~fI"

rem --- find a 64-bit Python 3 ---
set "PYCHK=import struct,sys; sys.exit(0 if struct.calcsize('P')==8 and sys.version_info>=(3,6) else 1)"
set "PY=python"
%PY% -c "%PYCHK%" >nul 2>&1 && goto havepy
set "PY=py -3-64"
%PY% -c "%PYCHK%" >nul 2>&1 && goto havepy
set "PY=py -3"
%PY% -c "%PYCHK%" >nul 2>&1 && goto havepy
echo These start files need Python 3 (64-bit) - free from https://www.python.org/downloads/windows/
echo (When installing, tick "Add python.exe to PATH".)
goto fail
:havepy

cd /d "%BIN%"
if /i "%MODE%"=="host" goto host
if /i "%MODE%"=="join" goto join
if /i "%MODE%"=="play" goto play
if /i "%MODE%"=="compile" goto compile
echo Unknown mode "%MODE%".
goto fail

:host
set "FILE=%~2"
set "PORT=%~3"
if "%PORT%"=="" set "PORT=5000"
if not "%FILE%"=="" goto host_go
echo Drag the world's .dmb file into this window (or type its path) and press Enter:
set /p "FILE="
set "FILE=%FILE:"=%"
:host_go
if not exist "%FILE%" echo File not found: "%FILE%" & goto fail
echo Hosting "%FILE%" with Dream Daemon 334 on port %PORT%.  Players join with "Join server (Dream Seeker 334).bat".
echo Close this window to stop the server.
%PY% -I "%HELPER%host334v3.py" "%BIN%\dreamdaemon.exe" "%FILE%" %PORT%
goto end

:join
set "ADDR=%~2"
if not "%ADDR%"=="" goto join_go
set "ADDR=127.0.0.1:5000"
echo Server address [Enter = 127.0.0.1:5000, the server on this PC; e.g. 192.168.1.20:5000]:
set /p "ADDR="
:join_go
echo Joining %ADDR% with Dream Seeker 334.  First screens: "Dream Seeker Diagnostics" - Cancel (if shown),
echo "Create/Retrieve Key" - Cancel, Login ("Guest") - OK.  Then it connects by itself.
%PY% -I "%HELPER%join334.py" "%BIN%\dreamseeker.exe" %ADDR%
goto end

:play
set "FILE=%~2"
if not "%FILE%"=="" goto play_go
echo Drag the world's .dmb file into this window (or type its path) and press Enter:
set /p "FILE="
set "FILE=%FILE:"=%"
:play_go
if not exist "%FILE%" echo File not found: "%FILE%" & goto fail
echo Playing "%FILE%" single-user in Dream Seeker 334.  First screens: Cancel / Cancel / OK as above.
%PY% -I "%HELPER%host334v2.py" "%BIN%\dreamseeker.exe" "%FILE%"
goto end

:compile
set "FILE=%~2"
if not "%FILE%"=="" goto compile_go
echo Drag the project's .dme file into this window (or type its path) and press Enter:
set /p "FILE="
set "FILE=%FILE:"=%"
:compile_go
if not exist "%FILE%" echo File not found: "%FILE%" & goto fail
echo Opening "%FILE%" in Dream Maker 334 (Build ^> Compile).
%PY% -I "%HELPER%host334v2.py" "%BIN%\dreammaker.exe" "%FILE%"
goto end

:fail
echo.
pause
exit /b 1
:end
if errorlevel 1 pause
